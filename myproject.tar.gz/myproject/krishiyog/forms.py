from django.forms import ModelForm
from .models import farm, farmer, field

class farmForm(ModelForm):

	class Meta:
			model=farm
			fields=['owner', 'year', 'season', 'geo_farm']

class farmerForm(ModelForm):

		class Meta:
				model=farmer
				fields= ['first_name','last_name','number_of_farms']

class fieldForm(ModelForm):

		class Meta:
				model=field
				fields=['farm','crop','geo_field']

