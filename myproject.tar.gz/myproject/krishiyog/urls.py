from django.conf.urls import url
from .import views

urlpatterns=[

	url(r'^$', views.items_list, name='items_list'),
	url(r'^farmers_list/$', views.farmers_list, name='farmers_list'),
	url(r'^add/farmer/$', views.add_farmer, name='add_farmer'),
	url(r'^edit/farmer/(?P<id>\d+)/$', views.edit_farmer, name='edit_farmer'),
	url(r'^delete/farmer/(?P<id>\d+)/$', views.delete_farmer, name='delete_farmer'),

]
