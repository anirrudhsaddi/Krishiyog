#from django.db import models
from django.contrib.gis.db import models



# Create your models here.

class farmer(models.Model):

    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    number_of_farms = models.IntegerField(default=0)

    def __str__(self):
	      return self.first_name





class farm(models.Model):

    owner = models.ForeignKey(farmer, on_delete=models.CASCADE)
    geo_farm = models.MultiPolygonField(srid=4326)
    year = models.IntegerField(default=0)
    season = models.CharField(max_length=100)
    def __str__(self):
		    return self.farm_name
																										    


class field(models.Model):

    farm = models.ForeignKey(farm, on_delete=models.CASCADE)
    crop = models.CharField(max_length=200)
    geo_field = models.MultiPolygonField(srid=4326)
