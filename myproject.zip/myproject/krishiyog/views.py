from django.shortcuts import render, get_object_or_404,redirect
from django.http import HttpResponse
from .forms import farmerForm, farmForm, fieldForm
from .models import farmer, farm, field

def index(request):

	return HttpResponse("You are at the landing page for Krishiyog's demo module")

# Create your views here.


def farm(request, farm_id):

	return HttpResponse(" You will see the list of fields in the farm here")


def field(request, field_id):

	return HttpResponse("You will see the details of the field here")


def items_list(request):
	return render(request, 'krishiyog/items_list.html',{})

def farmers_list(request):
	farmers_list = farmer.objects.all()
	return render(request, 'krishiyog/farmers_list.html',{'farmers_list':farmers_list})

def add_farmer(request):
		if request.method == "POST":
				form = farmerForm(request.POST)

				if form.is_valid():
						farmer_item = form.save(commit=False)
						farmer_item.save()
						return redirect('/farmers_list/')

		else:
				form = farmerForm()

		return render(request, 'krishiyog/add_farmer.html',{'form':form})

				
def edit_farmer(request, id=None):
		
		print ('Medthod request for edit:', request.method)
		if request.method=="POST":

			item=get_object_or_404(farmer, id=id)
			print (id,item)
			form=farmerForm(request.POST or None, instance=item)
			if form.is_valid():
				item=form.save(commit=False)
				item.save()
				return redirect('/farmers_list/')

			context = {

					"first_name" : item.first_name,
					"last_name" : item.last_name,
					"number_of_farms" : item.number_of_farms,
					"item" : item,
					"form": form,

					}
			return render(request, 'krishiyog/edit_farmer.html', context)


def delete_farmer(request, id=None):

		'''print('method request for delete: ', request.method)'''
		if request.method=="POST":
			farmer.objects.filter(id=id).delete()
			return redirect('/farmers_list/')
		
		'''item=get_object_or_404(farmer,id=id)

			form = farmerForm(request.POST or None, instance=item)
			if form.is_valid():
				item.delete()
				return redirect('/farmers_list')

		else:
				form=farmerForm()

		return redirect('/farmers_list/')'''
