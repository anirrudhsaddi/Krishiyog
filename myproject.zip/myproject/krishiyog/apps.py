from django.apps import AppConfig


class KrishiyogConfig(AppConfig):
    name = 'krishiyog'
